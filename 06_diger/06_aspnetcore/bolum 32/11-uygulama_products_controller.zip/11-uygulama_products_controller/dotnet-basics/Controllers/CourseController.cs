using Microsoft.AspNetCore.Mvc;

namespace dotnet_basics.Controllers;

public class CourseController : Controller
{

    // localhost:5158/course
    // localhost:5158/course/index
    public string Index()
    {
        return "Course/Index";
    }

    // localhost:5158/course/details
    public string Details()
    {
        return "Course/Details";
    }


    // localhost:5158/course/list
    public string List()
    {
        return "Course/List";
    }


}
