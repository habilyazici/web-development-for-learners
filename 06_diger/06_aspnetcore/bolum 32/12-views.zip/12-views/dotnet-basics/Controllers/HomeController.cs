using Microsoft.AspNetCore.Mvc;

namespace dotnet_basics.Controllers;

public class HomeController : Controller
{
    // localhost:5158/
    // localhost:5158/home
    // localhost:5158/home/index
    public ActionResult Index()
    {
        return View();  // View/Home/Index.cshtml
    }

    // localhost:5158/home/about
    public ActionResult About()
    {
        return View();  // View/Home/About.cshtml
    }

    // localhost:5158/home/contact
    public ActionResult Contact()
    {
        return View(); // View/Home/Contact.cshtml
    }
}





