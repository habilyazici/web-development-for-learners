using Microsoft.AspNetCore.Mvc;

namespace dotnet_basics.Controllers;

public class CourseController : Controller
{

    // localhost:5158/course
    // localhost:5158/course/index
    public ActionResult Index()
    {
        return View();  // Views/Course/Index.cshtml
    }

    // localhost:5158/course/details
    public ActionResult Details()
    {
        return View();  // Views/Course/Details.cshtml
    }


    // localhost:5158/course/list
    public ActionResult List()
    {
        return View();  // Views/Course/List.cshtml
    }


}
