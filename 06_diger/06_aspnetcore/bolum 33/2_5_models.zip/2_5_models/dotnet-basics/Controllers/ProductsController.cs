
using Microsoft.AspNetCore.Mvc;

namespace dotnet_basics.Controllers;

public class ProductsController : Controller
{
    public ActionResult Index()
    {
        return View();
    }

    public ActionResult List()
    {
        return View();
    }

    public ActionResult Details()
    {
        string urunBaslik = "Samsung S24 Ultra";
        string urunAciklama = "Samsung Galaxy S24 Ultra 512 GB 12 GB Ram (Samsung Türkiye Garantili) Siyah";
        double urunFiyat = 70000;
        string urunResim = "samsung-s24.jpg";
        bool urunSatistami = false;

        ViewData["urunBaslik"] = urunBaslik;
        ViewData["urunAciklama"] = urunAciklama;
        ViewData["urunFiyat"] = urunFiyat;
        ViewData["urunResim"] = urunResim;
        ViewData["urunSatistami"] = urunSatistami;

        return View();
    }
}
