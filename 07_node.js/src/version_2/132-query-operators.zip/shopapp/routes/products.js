const express = require("express");
const router = express.Router();

const {Product, validateProduct} = require("../models/product");

const products = [
    { id: 1, name: "iphone 12", price: 20000 },
    { id: 2, name: "iphone 13", price: 30000 },
    { id: 3, name: "iphone 14", price: 40000 }
];

// Query Operators
// eq => equal
// ne => not equal
// gt => greater than
// gte => greater than or equal
// lt => less than
// lte => less than or equal
// in => [10,20,30]
// nin => [10,20]

router.get("/", async (req, res) => {
    // const products = await Product.find();
    // const products = await Product.find({ price: { $eq: 10000 } });
    // const products = await Product.find({ price: { $ne: 10000 } });
    // const products = await Product.find({ price: { $gt: 10000 } });
    // const products = await Product.find({ price: { $gte: 10000 } });
    // const products = await Product.find({ price: { $lt: 10000 } }); // price < 10000
    // const products = await Product.find({ price: { $lte: 10000 } }); // price <= 10000
    // const products = await Product.find({ price: { $in: [10000, 20000] } });
    // const products = await Product.find({ price: { $nin: [10000, 20000] } });
    // const products = await Product.find({ price: { $gte: 10000, $lte: 20000 } });
    // const products = await Product.find({ price: { $gte: 10000, $lte: 20000 }, name: "Samsung" }); // and
    // const products = await Product.find()
    //                             .or([
    //                                 { price: { $gte: 10000} }, 
    //                                 {isActive: true }
    //                             ]); // (price >= 10000 or isActive==true)


    // startwith
    // const products = await Product.find({ name: /^iphone/ });

    // endwith
    // const products = await Product.find({ name: /iphone$/ });

    // contains
    const products = await Product.find({ name: /.*iphone.*/i });
    
    res.send(products);
});

router.post("/", async (req, res) => {
    const { error } =  validateProduct(req.body);

    if(error) {
        return res.status(400).send(error.details[0].message);
    }

    const product = new Product({
        name: req.body.name,
        price: req.body.price,
        description: req.body.description,
        imageUrl: req.body.imageUrl,
        isActive: req.body.isActive
    });

    try {
        const result = await product.save();
        res.send(result);
    }
    catch(err) {
        console.log(err);
    }
});

router.put("/:id", (req, res) => {
    const product = products.find(p => p.id == req.params.id);
    if(!product) {
        return res.status(404).send("aradığınız ürün bulunamadı.");
    }

    const { error } = validateProduct(req.body);

    if(error) {
        return res.status(400).send(result.error.details[0].message);
    }

    product.name = req.body.name;
    product.price = req.body.price;

    res.send(product);
});

router.delete("/:id", (req, res) => {
    const product = products.find(p => p.id == req.params.id);
    if(!product) {
        return res.status(404).send("aradığınız ürün bulunamadı.");
    }

    const index = products.indexOf(product);
    products.splice(index, 1);
    res.send(product);
});

router.get("/:id", async (req, res) => {
    // const product = await Product.findOne({ _id: req.params.id}); 
    const product = await Product.findById(req.params.id); 

    if(!product) {
        return res.status(404).send("aradığınız ürün bulunamadı.");
    }
    res.send(product);
});



module.exports = router;