const config = require("config");
const express = require("express");
const app = express();

const mongoose = require("mongoose");

const products = require("./routes/products");
const categories = require("./routes/categories");
const users = require("./routes/users");
const home = require("./routes/home");

const error = require("./middleware/error");
const logger = require("./middleware/logger");

app.use(express.json());

app.use("/api/products" ,products);
app.use("/api/categories" ,categories);
app.use("/api/users" ,users);
app.use("/", home);

app.use(error);

throw new Error("uncaught exception *** ");

// const p = Promise.reject(new Error("hata"));
// p.then(() => console.log("success"))

const username = config.get("db.username");
const password = config.get("db.password");
const database = config.get("db.name");

mongoose
    .connect(`mongodb+srv://${username}:${password}@cluster0.kfjfak2.mongodb.net/${database}?retryWrites=true&w=majority`)
    .then(() => console.log("mongodb bağlantısı kuruldu."))

const port = process.env.PORT || 3000;

app.listen(port, () => {
    console.log(`listening on port ${port}`);
});