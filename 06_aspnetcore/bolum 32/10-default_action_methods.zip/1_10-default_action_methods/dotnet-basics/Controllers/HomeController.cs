using Microsoft.AspNetCore.Mvc;

namespace dotnet_basics.Controllers;

public class HomeController : Controller
{
    // localhost:5158/
    // localhost:5158/home
    // localhost:5158/home/index
    public string Index()
    {
        return "Home/Index";
    }

    // localhost:5158/home/about
    public string About()
    {
        return "Home/about";
    }

    // localhost:5158/home/contact
    public string Contact()
    {
        return "Home/Contact";
    }
}

// localhost:3000/
// localhost:3000/products
// localhost:3000/products/list
// localhost:3000/products/details

// ProductsController
// Index
// List
// Details
// Update



