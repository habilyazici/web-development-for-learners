using Microsoft.AspNetCore.Mvc;

namespace dotnet_basics.Controllers;

public class CourseController : Controller
{

    // localhost:5158/course
    // localhost:5158/course/list
    // localhost:5158/course/details

    public string List()
    {
        return "List";
    }


}
