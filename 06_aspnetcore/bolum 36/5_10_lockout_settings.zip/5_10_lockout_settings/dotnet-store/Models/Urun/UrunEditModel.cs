namespace dotnet_store.Models;
public class UrunEditModel : UrunModel
{
    public int Id { get; set; }
    public string? ResimAdi { get; set; }
}
