using Microsoft.AspNetCore.Identity;

namespace dotnet_store.Models;

public class AppRole : IdentityRole<int>
{

}