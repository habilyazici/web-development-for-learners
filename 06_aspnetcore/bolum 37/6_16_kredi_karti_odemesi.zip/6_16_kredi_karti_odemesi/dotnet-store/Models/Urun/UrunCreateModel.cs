using System.ComponentModel.DataAnnotations;

namespace dotnet_store.Models;

public class UrunCreateModel : UrunModel
{

}